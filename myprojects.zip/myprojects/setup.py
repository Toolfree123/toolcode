from setuptools import setup
setup(
    name='toolcode',
    version='0.1',
    description='Testing installation of First Package',
    url='https://zalo.me/g/apbppv905',
    author='kythai',
    author_email='kyhacknao@gmail.com',
    license='MIT',
    packages=['toolcode'],
    zip_safe=False
)